var annotated_dup =
[
    [ "QMdmmCore", "d7/dd6/namespaceQMdmmCore.html", [
      [ "Utilities", "dd/d15/namespaceQMdmmCore_1_1Utilities.html", [
        [ "DependentFalse", "d1/dac/structQMdmmCore_1_1Utilities_1_1DependentFalse.html", null ]
      ] ],
      [ "Packet", "dc/dd8/classQMdmmCore_1_1Packet.html", "dc/dd8/classQMdmmCore_1_1Packet" ],
      [ "LogicConfiguration", "dc/db8/classQMdmmCore_1_1LogicConfiguration.html", "dc/db8/classQMdmmCore_1_1LogicConfiguration" ],
      [ "Room", "d8/d24/classQMdmmCore_1_1Room.html", "d8/d24/classQMdmmCore_1_1Room" ],
      [ "Player", "d2/d1a/classQMdmmCore_1_1Player.html", "d2/d1a/classQMdmmCore_1_1Player" ],
      [ "Logic", "d7/dd6/classQMdmmCore_1_1Logic.html", "d7/dd6/classQMdmmCore_1_1Logic" ],
      [ "Settings", "d6/d5a/classQMdmmCore_1_1Settings.html", "d6/d5a/classQMdmmCore_1_1Settings" ]
    ] ],
    [ "QMdmmNetworking", "d2/dbe/namespaceQMdmmNetworking.html", [
      [ "ServerConfiguration", "d8/d03/structQMdmmNetworking_1_1ServerConfiguration.html", "d8/d03/structQMdmmNetworking_1_1ServerConfiguration" ],
      [ "Server", "d0/d8b/classQMdmmNetworking_1_1Server.html", "d0/d8b/classQMdmmNetworking_1_1Server" ],
      [ "Agent", "d8/dec/classQMdmmNetworking_1_1Agent.html", "d8/dec/classQMdmmNetworking_1_1Agent" ],
      [ "ClientConfiguration", "dc/dcb/structQMdmmNetworking_1_1ClientConfiguration.html", "dc/dcb/structQMdmmNetworking_1_1ClientConfiguration" ],
      [ "Client", "d8/de3/classQMdmmNetworking_1_1Client.html", "d8/de3/classQMdmmNetworking_1_1Client" ],
      [ "LogicRunner", "da/d9f/classQMdmmNetworking_1_1LogicRunner.html", "da/d9f/classQMdmmNetworking_1_1LogicRunner" ],
      [ "Socket", "d5/d88/classQMdmmNetworking_1_1Socket.html", "d5/d88/classQMdmmNetworking_1_1Socket" ]
    ] ]
];