var namespaceQMdmmCore =
[
    [ "Data", "d8/da6/namespaceQMdmmCore_1_1Data.html", [
      [ "Place", "d8/da6/namespaceQMdmmCore_1_1Data.html#a9e0e8b35ac8bf040bb8473b33a7bbb2d", [
        [ "Village", "d8/da6/namespaceQMdmmCore_1_1Data.html#a9e0e8b35ac8bf040bb8473b33a7bbb2da07bef0ecc167fb149cef53503578a9c2", null ]
      ] ],
      [ "DamageReason", "d8/da6/namespaceQMdmmCore_1_1Data.html#a550a7c09c7ce7f41a308642880178040", [
        [ "DamageReasonUnknown", "d8/da6/namespaceQMdmmCore_1_1Data.html#a550a7c09c7ce7f41a308642880178040af99f9084ddc46620843d6d183f200e96", null ],
        [ "Slashed", "d8/da6/namespaceQMdmmCore_1_1Data.html#a550a7c09c7ce7f41a308642880178040a17462495102c5d850ce8a94d0d0726b2", null ],
        [ "Kicked", "d8/da6/namespaceQMdmmCore_1_1Data.html#a550a7c09c7ce7f41a308642880178040a6b5487de8a929d7cb8cbd625c8e51aa1", null ],
        [ "HpPunished", "d8/da6/namespaceQMdmmCore_1_1Data.html#a550a7c09c7ce7f41a308642880178040ad92f362c63c984b50123913c2a7ecc37", null ]
      ] ],
      [ "RockPaperScissors", "d8/da6/namespaceQMdmmCore_1_1Data.html#a6626aff987f5f428512a4e55a8c27911", [
        [ "Rock", "d8/da6/namespaceQMdmmCore_1_1Data.html#a6626aff987f5f428512a4e55a8c27911abdd400a48624539fb8cf1240af84487a", null ],
        [ "Paper", "d8/da6/namespaceQMdmmCore_1_1Data.html#a6626aff987f5f428512a4e55a8c27911a6fb0e2dd1f7d95fb0e2b67dfd7d59c29", null ],
        [ "Scissors", "d8/da6/namespaceQMdmmCore_1_1Data.html#a6626aff987f5f428512a4e55a8c27911ab03c312bd77f754c3a9709aabb396d79", null ]
      ] ],
      [ "Action", "d8/da6/namespaceQMdmmCore_1_1Data.html#a461e2f0a2b58ce711e7067363754c6ff", [
        [ "DoNothing", "d8/da6/namespaceQMdmmCore_1_1Data.html#a461e2f0a2b58ce711e7067363754c6ffa860ac6f0085705c49901e0e5446f1c6a", null ],
        [ "BuyKnife", "d8/da6/namespaceQMdmmCore_1_1Data.html#a461e2f0a2b58ce711e7067363754c6ffa33a93365a0988f83a3e753a07a2425f8", null ],
        [ "BuyHorse", "d8/da6/namespaceQMdmmCore_1_1Data.html#a461e2f0a2b58ce711e7067363754c6ffa1a22a5b705de7c35048110646135dfee", null ],
        [ "Slash", "d8/da6/namespaceQMdmmCore_1_1Data.html#a461e2f0a2b58ce711e7067363754c6ffa4f24b3259dc71b4b05fb7788472da43c", null ],
        [ "Kick", "d8/da6/namespaceQMdmmCore_1_1Data.html#a461e2f0a2b58ce711e7067363754c6ffa43a944b4c75d3bac3d728a723fe854f4", null ],
        [ "Move", "d8/da6/namespaceQMdmmCore_1_1Data.html#a461e2f0a2b58ce711e7067363754c6ffaf81199656cc4c9cca5ad7085835328bb", null ],
        [ "LetMove", "d8/da6/namespaceQMdmmCore_1_1Data.html#a461e2f0a2b58ce711e7067363754c6ffa7edcb452c01ed87e2eeca86d09e75feb", null ]
      ] ],
      [ "UpgradeItem", "d8/da6/namespaceQMdmmCore_1_1Data.html#a7069d168ea8678628314279a6d01876d", [
        [ "UpgradeKnife", "d8/da6/namespaceQMdmmCore_1_1Data.html#a7069d168ea8678628314279a6d01876da018482fd93ca3eb2af07c697ce373f29", null ],
        [ "UpgradeHorse", "d8/da6/namespaceQMdmmCore_1_1Data.html#a7069d168ea8678628314279a6d01876da478a1d939bc9aca24a5ba959aca99221", null ],
        [ "UpgradeMaxHp", "d8/da6/namespaceQMdmmCore_1_1Data.html#a7069d168ea8678628314279a6d01876da452c2a2bf9aa6257cb7791ce4901515c", null ]
      ] ],
      [ "AgentStateEnum", "d8/da6/namespaceQMdmmCore_1_1Data.html#a520344efba8987a287d13e3f01adece3", [
        [ "StateMaskOnline", "d8/da6/namespaceQMdmmCore_1_1Data.html#a520344efba8987a287d13e3f01adece3a5ed979802dc79a29d88ffc7b00b77584", null ],
        [ "StateMaskBot", "d8/da6/namespaceQMdmmCore_1_1Data.html#a520344efba8987a287d13e3f01adece3ac2794e047b886b50fc3b63831f2c7be5", null ],
        [ "StateMaskTrust", "d8/da6/namespaceQMdmmCore_1_1Data.html#a520344efba8987a287d13e3f01adece3abaa38509ef3e3a224dd2b35f79122831", null ],
        [ "StateOffline", "d8/da6/namespaceQMdmmCore_1_1Data.html#a520344efba8987a287d13e3f01adece3a79aabf1ffd15e28cb42fdd4d28766d3a", null ],
        [ "StateOfflineBot", "d8/da6/namespaceQMdmmCore_1_1Data.html#a520344efba8987a287d13e3f01adece3ade1de8ab1432044a068bdd26a7ba6ecc", null ],
        [ "StateOnline", "d8/da6/namespaceQMdmmCore_1_1Data.html#a520344efba8987a287d13e3f01adece3a990e99221647f38b0399f001c8a1e3bc", null ],
        [ "StateOnlineBot", "d8/da6/namespaceQMdmmCore_1_1Data.html#a520344efba8987a287d13e3f01adece3a9d56a91e2a41bc9c7a1f9f4248135313", null ],
        [ "StateOnlineTrust", "d8/da6/namespaceQMdmmCore_1_1Data.html#a520344efba8987a287d13e3f01adece3a79bd330e6999edf8986c287b911c6927", null ]
      ] ],
      [ "isPlaceAdjacent", "d8/da6/namespaceQMdmmCore_1_1Data.html#a8b250e3e72813d5468f8a42493e99d7b", null ],
      [ "rockPaperScissorsWinners", "d8/da6/namespaceQMdmmCore_1_1Data.html#a6e4006c543d421f7ab8f027bf80ef5fd", null ]
    ] ],
    [ "Global", "d9/db2/namespaceQMdmmCore_1_1Global.html", [
      [ "version", "d9/db2/namespaceQMdmmCore_1_1Global.html#ac676b0404108df289a8af811a8553cd7", null ]
    ] ],
    [ "Utilities", "dd/d15/namespaceQMdmmCore_1_1Utilities.html", "dd/d15/namespaceQMdmmCore_1_1Utilities" ],
    [ "Packet", "dc/dd8/classQMdmmCore_1_1Packet.html", "dc/dd8/classQMdmmCore_1_1Packet" ],
    [ "LogicConfiguration", "dc/db8/classQMdmmCore_1_1LogicConfiguration.html", "dc/db8/classQMdmmCore_1_1LogicConfiguration" ],
    [ "Room", "d8/d24/classQMdmmCore_1_1Room.html", "d8/d24/classQMdmmCore_1_1Room" ],
    [ "Player", "d2/d1a/classQMdmmCore_1_1Player.html", "d2/d1a/classQMdmmCore_1_1Player" ],
    [ "Logic", "d7/dd6/classQMdmmCore_1_1Logic.html", "d7/dd6/classQMdmmCore_1_1Logic" ],
    [ "Settings", "d6/d5a/classQMdmmCore_1_1Settings.html", "d6/d5a/classQMdmmCore_1_1Settings" ],
    [ "qMdmmDebugSetDevice", "d7/dd6/namespaceQMdmmCore.html#ae48134f9388424fd7fb425f8c3fd0098", null ]
];