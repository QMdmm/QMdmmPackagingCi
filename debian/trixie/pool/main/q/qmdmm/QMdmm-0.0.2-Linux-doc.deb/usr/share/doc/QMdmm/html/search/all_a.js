var searchData=
[
  ['layers_0',['Two layers',['../d2/d60/md_architecture.html#autotoc_md13',1,'']]],
  ['layout_1',['Directory layout',['../index.html#autotoc_md10',1,'']]],
  ['layout_20default_2',['Plain prefix layout (default)',['../d1/dce/md_getting-started.html#autotoc_md23',1,'']]],
  ['letmove_3',['letmove',['../d2/d1a/classQMdmmCore_1_1Player.html#ac374503eaf3af370a4b58dc8ba200832',1,'QMdmmCore::Player::letMove()'],['../d8/da6/namespaceQMdmmCore_1_1Data.html#a461e2f0a2b58ce711e7067363754c6ffa685bb74a3dcc98248dabed2030c39966',1,'QMdmmCore::Data::LetMove']]],
  ['library_4',['QMdmm Core library',['../d7/dbf/group__QMdmmCore.html',1,'']]],
  ['license_5',['License',['../index.html#autotoc_md11',1,'']]],
  ['list_6',['Todo List',['../dd/da0/todo.html',1,'']]],
  ['list2set_7',['list2Set',['../dd/d15/namespaceQMdmmCore_1_1Utilities.html#aa66b948d59059248d68c1474c4b4a84c',1,'QMdmmCore::Utilities']]],
  ['listen_8',['listen',['../d0/d8b/classQMdmmNetworking_1_1Server.html#a44debed350001325a80245589ea65f7f',1,'QMdmmNetworking::Server']]],
  ['listenerror_9',['listenError',['../d0/d8b/classQMdmmNetworking_1_1Server.html#a288d1a78feceabac4fc2a0938826fda3',1,'QMdmmNetworking::Server']]],
  ['local_20game_20runs_10',['The programs a local game runs',['../d1/dce/md_getting-started.html#autotoc_md31',1,'']]],
  ['localenabled_11',['localenabled',['../d8/d03/structQMdmmNetworking_1_1ServerConfiguration.html#a40f2c4b00a315145445149974c140229',1,'QMdmmNetworking::ServerConfiguration::localEnabled'],['../d8/d03/structQMdmmNetworking_1_1ServerConfiguration.html#a7b64020e483717de962d6c72973e5cd6',1,'QMdmmNetworking::ServerConfiguration::localEnabled() const']]],
  ['localsocketname_12',['localsocketname',['../d8/d03/structQMdmmNetworking_1_1ServerConfiguration.html#a7674c5046fc9edc55b341db525582047',1,'QMdmmNetworking::ServerConfiguration::localSocketName() const'],['../d8/d03/structQMdmmNetworking_1_1ServerConfiguration.html#a5288e7e84650c03833f0838adaa54bb7',1,'QMdmmNetworking::ServerConfiguration::localSocketName']]],
  ['logic_13',['logic',['../d7/dd6/classQMdmmCore_1_1Logic.html#a3bb577ff9d478e128046b68b555914e7',1,'QMdmmCore::Logic::Logic()'],['../d7/dd6/classQMdmmCore_1_1Logic.html',1,'QMdmmCore::Logic']]],
  ['logicconfiguration_14',['logicconfiguration',['../dc/db8/classQMdmmCore_1_1LogicConfiguration.html',1,'QMdmmCore::LogicConfiguration'],['../d8/d24/classQMdmmCore_1_1Room.html#af0be78e1848ffa248bb3f9f5db9d5908',1,'QMdmmCore::Room::logicConfiguration()']]],
  ['logicconfigurationnotified_15',['logicConfigurationNotified',['../d8/dec/classQMdmmNetworking_1_1Agent.html#a6d6fee9cd62866c5d68ff9b59588b101',1,'QMdmmNetworking::Agent']]],
  ['logicrunner_16',['logicrunner',['../da/d9f/classQMdmmNetworking_1_1LogicRunner.html#adeb157f7c8ffcb431fa3527d015ab912',1,'QMdmmNetworking::LogicRunner::LogicRunner()'],['../da/d9f/classQMdmmNetworking_1_1LogicRunner.html',1,'QMdmmNetworking::LogicRunner']]],
  ['logicrunner_20bridge_17',['The LogicRunner bridge',['../d2/d60/md_architecture.html#autotoc_md16',1,'']]]
];
