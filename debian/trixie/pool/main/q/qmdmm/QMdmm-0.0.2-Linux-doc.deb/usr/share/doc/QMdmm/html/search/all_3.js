var searchData=
[
  ['damaged_0',['damaged',['../d2/d1a/classQMdmmCore_1_1Player.html#a23cb2bb0117f6c3de3a03cc2a092d7fc',1,'QMdmmCore::Player']]],
  ['damagereason_1',['DamageReason',['../d8/da6/namespaceQMdmmCore_1_1Data.html#a550a7c09c7ce7f41a308642880178040',1,'QMdmmCore::Data']]],
  ['damagereasonunknown_2',['DamageReasonUnknown',['../d8/da6/namespaceQMdmmCore_1_1Data.html#a550a7c09c7ce7f41a308642880178040a10112b33b7372c40c2e2c40b5dd1c3b1',1,'QMdmmCore::Data']]],
  ['dead_3',['dead',['../d2/d1a/classQMdmmCore_1_1Player.html#a9705455c24558d83b54853a2b47c7ff9',1,'QMdmmCore::Player::dead'],['../d2/d1a/classQMdmmCore_1_1Player.html#ae9cc10f5153b231daec62b10e5ce22a9',1,'QMdmmCore::Player::dead() const']]],
  ['deadathp_4',['deadAtHp',['../d2/d1a/classQMdmmCore_1_1Player.html#a776e6ffe225cbcaa593e89161d3c9740',1,'QMdmmCore::Player']]],
  ['default_5',['Plain prefix layout (default)',['../d1/dce/md_getting-started.html#autotoc_md23',1,'']]],
  ['defaults_6',['defaults',['../dc/db8/classQMdmmCore_1_1LogicConfiguration.html#a91835cbb24e48f58e36a5ba6d18ab625',1,'QMdmmCore::LogicConfiguration::defaults()'],['../d8/d03/structQMdmmNetworking_1_1ServerConfiguration.html#a14b85d9d504717a5c105527b52807fa9',1,'QMdmmNetworking::ServerConfiguration::defaults()'],['../dc/dcb/structQMdmmNetworking_1_1ClientConfiguration.html#a147eab0cfce2705ed0adb44dbf500c2b',1,'QMdmmNetworking::ClientConfiguration::defaults()']]],
  ['dependentfalse_7',['dependentfalse',['../dd/d15/namespaceQMdmmCore_1_1Utilities.html#a8a28e08b38df552571a1f1df4837f78f',1,'QMdmmCore::Utilities::dependentFalse'],['../d1/dac/structQMdmmCore_1_1Utilities_1_1DependentFalse.html',1,'QMdmmCore::Utilities::DependentFalse&lt;... &gt;']]],
  ['deserialize_8',['deserialize',['../d8/d03/structQMdmmNetworking_1_1ServerConfiguration.html#ac404df6be44cb2a3aed73256f2974cdc',1,'QMdmmNetworking::ServerConfiguration::deserialize()'],['../dc/db8/classQMdmmCore_1_1LogicConfiguration.html#a07f6a729c86c4f119f5d574287abd44d',1,'QMdmmCore::LogicConfiguration::deserialize()']]],
  ['die_9',['die',['../d2/d1a/classQMdmmCore_1_1Player.html#a2c3b15ffb0809008c4ca4fa3fdf07037',1,'QMdmmCore::Player']]],
  ['directory_20layout_10',['Directory layout',['../index.html#autotoc_md10',1,'']]],
  ['disconnectfromhost_11',['disconnectfromhost',['../d8/de3/classQMdmmNetworking_1_1Client.html#a733417507e90e004fc47e2e05e0ea0ce',1,'QMdmmNetworking::Client::disconnectFromHost()'],['../d5/d88/classQMdmmNetworking_1_1Socket.html#a0eaad0d64e9249919d804482fc5bd661',1,'QMdmmNetworking::Socket::disconnectFromHost()']]],
  ['disk_20image_12',['Disk image',['../d1/dce/md_getting-started.html#autotoc_md25',1,'']]],
  ['documentation_13',['Documentation',['../index.html#autotoc_md5',1,'']]],
  ['donothing_14',['donothing',['../d8/da6/namespaceQMdmmCore_1_1Data.html#a461e2f0a2b58ce711e7067363754c6ffa956f9e0e5bad7755c5a897a23bd7c5cd',1,'QMdmmCore::Data::DoNothing'],['../d2/d1a/classQMdmmCore_1_1Player.html#ae2a26f8b30154c49da30649c22aaaa43',1,'QMdmmCore::Player::doNothing()']]],
  ['drive_20a_20client_20yourself_15',['Drive a client yourself',['../d1/dce/md_getting-started.html#autotoc_md34',1,'']]]
];
