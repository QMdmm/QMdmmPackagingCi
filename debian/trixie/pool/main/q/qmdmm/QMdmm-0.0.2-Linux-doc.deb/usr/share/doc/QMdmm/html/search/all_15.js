var searchData=
[
  ['websocketenabled_0',['websocketenabled',['../d8/d03/structQMdmmNetworking_1_1ServerConfiguration.html#a1fe135c77ca9d23c3c20ca4b88ebc0c4',1,'QMdmmNetworking::ServerConfiguration::websocketEnabled'],['../d8/d03/structQMdmmNetworking_1_1ServerConfiguration.html#a34a0745847791b7ab82f025c7686640e',1,'QMdmmNetworking::ServerConfiguration::websocketEnabled() const']]],
  ['websocketname_1',['websocketname',['../d8/d03/structQMdmmNetworking_1_1ServerConfiguration.html#a3f8de0c7d20288dc6304457a59cde5f4',1,'QMdmmNetworking::ServerConfiguration::websocketName'],['../d8/d03/structQMdmmNetworking_1_1ServerConfiguration.html#a6221d690c7426d1d8a858e1d32c6e70b',1,'QMdmmNetworking::ServerConfiguration::websocketName() const']]],
  ['websocketport_2',['websocketport',['../d8/d03/structQMdmmNetworking_1_1ServerConfiguration.html#a0fb5f3f77476d747913c6e27d02a5776',1,'QMdmmNetworking::ServerConfiguration::websocketPort'],['../d8/d03/structQMdmmNetworking_1_1ServerConfiguration.html#aef188884949fdabb70cc0b4f9096f6ce',1,'QMdmmNetworking::ServerConfiguration::websocketPort() const']]],
  ['where_20the_20settings_20are_20stored_3',['Where the settings are stored',['../d1/dce/md_getting-started.html#autotoc_md27',1,'']]]
];
