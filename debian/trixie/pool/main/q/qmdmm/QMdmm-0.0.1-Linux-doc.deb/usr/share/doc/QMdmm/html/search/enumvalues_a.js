var searchData=
[
  ['requestaction_0',['RequestAction',['../d4/df8/qmdmmprotocol_8h.html#a601aabe13e97ec4f838dc525d32bbe4caf42b44fdf8b5d9f927e6dcfd6d7a30dc',1,'QMdmmCore::Protocol']]],
  ['requestactionorder_1',['RequestActionOrder',['../d4/df8/qmdmmprotocol_8h.html#a601aabe13e97ec4f838dc525d32bbe4ca769edacd49975c1f50ecc891e6b6c772',1,'QMdmmCore::Protocol']]],
  ['requestinvalid_2',['RequestInvalid',['../d4/df8/qmdmmprotocol_8h.html#a601aabe13e97ec4f838dc525d32bbe4ca46bd3b5611674fb922b9b20011653f57',1,'QMdmmCore::Protocol']]],
  ['requestrockpaperscissors_3',['RequestRockPaperScissors',['../d4/df8/qmdmmprotocol_8h.html#a601aabe13e97ec4f838dc525d32bbe4ca56a93e68511d3bb4fe69cfc775449f65',1,'QMdmmCore::Protocol']]],
  ['requestupgrade_4',['RequestUpgrade',['../d4/df8/qmdmmprotocol_8h.html#a601aabe13e97ec4f838dc525d32bbe4ca7fa2c083f87bcd26ae308b85494a691b',1,'QMdmmCore::Protocol']]],
  ['rock_5',['Rock',['../d8/da6/namespaceQMdmmCore_1_1Data.html#a6626aff987f5f428512a4e55a8c27911aa4b7058953ec10b9036278c7f424e73b',1,'QMdmmCore::Data']]],
  ['rounddown_6',['RoundDown',['../dc/db8/classQMdmmCore_1_1LogicConfiguration.html#ab00c24deed7347b615da2215f35d9dfaae8f28a674dbcc9bd1c635d6f95080716',1,'QMdmmCore::LogicConfiguration']]],
  ['roundtonearest45_7',['RoundToNearest45',['../dc/db8/classQMdmmCore_1_1LogicConfiguration.html#ab00c24deed7347b615da2215f35d9dfaacf540d4b112ae31f73be6e79b33c030f',1,'QMdmmCore::LogicConfiguration']]],
  ['roundup_8',['RoundUp',['../dc/db8/classQMdmmCore_1_1LogicConfiguration.html#ab00c24deed7347b615da2215f35d9dfaa83c482a76558c4bef606423bc4476f05',1,'QMdmmCore::LogicConfiguration']]],
  ['rpsforaction_9',['RpsForAction',['../d7/dd6/classQMdmmCore_1_1Logic.html#a98d6efca8d76beee57b6f6f1bb7a471eaff4c25b1da9af60dcf38048e7c6938f4',1,'QMdmmCore::Logic']]],
  ['rpsforactionorder_10',['RpsForActionOrder',['../d7/dd6/classQMdmmCore_1_1Logic.html#a98d6efca8d76beee57b6f6f1bb7a471ea70006afca8e3339473993d7628f00ffc',1,'QMdmmCore::Logic']]]
];
