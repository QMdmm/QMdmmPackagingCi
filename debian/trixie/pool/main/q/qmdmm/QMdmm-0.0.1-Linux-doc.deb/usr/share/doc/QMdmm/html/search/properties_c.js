var searchData=
[
  ['tcpenabled_0',['tcpEnabled',['../d8/d03/structQMdmmNetworking_1_1ServerConfiguration.html#a6b44352e23bbd06e46e185e92da58e69',1,'QMdmmNetworking::ServerConfiguration']]],
  ['tcpport_1',['tcpPort',['../d8/d03/structQMdmmNetworking_1_1ServerConfiguration.html#a2d3bc4bf00678638cacb7a97755496b6',1,'QMdmmNetworking::ServerConfiguration']]]
];
