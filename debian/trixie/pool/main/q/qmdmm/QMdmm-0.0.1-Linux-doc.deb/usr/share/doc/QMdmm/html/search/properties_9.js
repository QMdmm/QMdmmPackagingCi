var searchData=
[
  ['place_0',['place',['../d2/d1a/classQMdmmCore_1_1Player.html#a7ce093ed6585446daae136b29512ab4d',1,'QMdmmCore::Player']]],
  ['playernumperroom_1',['playerNumPerRoom',['../d8/d03/structQMdmmNetworking_1_1ServerConfiguration.html#afb057c6518d3366b79ec1799319a3188',1,'QMdmmNetworking::ServerConfiguration']]],
  ['punishhpmodifier_2',['punishHpModifier',['../dc/db8/classQMdmmCore_1_1LogicConfiguration.html#aaac7bd215f09dbb12f66775d618e2cf3',1,'QMdmmCore::LogicConfiguration']]],
  ['punishhproundstrategy_3',['punishHpRoundStrategy',['../dc/db8/classQMdmmCore_1_1LogicConfiguration.html#ae17d0b86dfd8dfdcaa3524df2e95f174',1,'QMdmmCore::LogicConfiguration']]]
];
