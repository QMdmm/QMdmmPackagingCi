var searchData=
[
  ['errorstring_0',['errorString',['../d8/d11/structQMdmmNetworking_1_1Socket_1_1Error.html#a058dcc230a87c868e856fecdeece6e71',1,'QMdmmNetworking::Socket::Error']]]
];
