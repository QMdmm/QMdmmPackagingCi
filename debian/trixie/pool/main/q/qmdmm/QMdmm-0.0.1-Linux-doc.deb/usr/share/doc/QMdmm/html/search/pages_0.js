var searchData=
[
  ['architecture_0',['Architecture',['../d2/d60/md_architecture.html',1,'']]]
];
