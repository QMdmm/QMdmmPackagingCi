var searchData=
[
  ['gameover_0',['gameover',['../d7/dd6/classQMdmmCore_1_1Logic.html#a1a0a11ee662b60633920940e8888ca7e',1,'QMdmmCore::Logic::gameOver()'],['../da/d9f/classQMdmmNetworking_1_1LogicRunner.html#a0f16211c1f27b1f044196bea47c60815',1,'QMdmmNetworking::LogicRunner::gameOver()']]],
  ['gameovernotified_1',['gameOverNotified',['../d8/dec/classQMdmmNetworking_1_1Agent.html#a605e438198cf3aa6fb6958612afa3a15',1,'QMdmmNetworking::Agent']]],
  ['gamestartnotified_2',['gameStartNotified',['../d8/dec/classQMdmmNetworking_1_1Agent.html#aa5e32c322a5178edca23dd28711b3ab7',1,'QMdmmNetworking::Agent']]],
  ['giveuprequest_3',['giveUpRequest',['../d8/dec/classQMdmmNetworking_1_1Agent.html#ab1252b1cfc09dc9b747deca2e6a713e3',1,'QMdmmNetworking::Agent']]]
];
