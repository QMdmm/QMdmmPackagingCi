var searchData=
[
  ['image_0',['Disk image',['../d1/dce/md_getting-started.html#autotoc_md25',1,'']]],
  ['initialhorsedamage_1',['initialhorsedamage',['../dc/db8/classQMdmmCore_1_1LogicConfiguration.html#ad0a69ad5b7db817aac5c02740e8b33e8',1,'QMdmmCore::LogicConfiguration::initialHorseDamage() const'],['../dc/db8/classQMdmmCore_1_1LogicConfiguration.html#a0cf7aaa4400c82ca63009c246488d113',1,'QMdmmCore::LogicConfiguration::initialHorseDamage']]],
  ['initialknifedamage_2',['initialknifedamage',['../dc/db8/classQMdmmCore_1_1LogicConfiguration.html#aad39e9c0baca4f8a2116c67316e34a64',1,'QMdmmCore::LogicConfiguration::initialKnifeDamage'],['../dc/db8/classQMdmmCore_1_1LogicConfiguration.html#a6a58776014ea657b803b2277e4cec05e',1,'QMdmmCore::LogicConfiguration::initialKnifeDamage() const']]],
  ['initialmaxhp_3',['initialmaxhp',['../dc/db8/classQMdmmCore_1_1LogicConfiguration.html#a1f2042a7ccb150143094f674dbcf95e2',1,'QMdmmCore::LogicConfiguration::initialMaxHp'],['../dc/db8/classQMdmmCore_1_1LogicConfiguration.html#aa92b38b7682a65e1595bca3b573b20b8',1,'QMdmmCore::LogicConfiguration::initialMaxHp() const']]],
  ['initialplace_4',['initialplace',['../d2/d1a/classQMdmmCore_1_1Player.html#a41a2757902cd7a502e1318c48222333b',1,'QMdmmCore::Player::initialPlace'],['../d2/d1a/classQMdmmCore_1_1Player.html#a8c5425568c0c4dd3929b884259ec0f2d',1,'QMdmmCore::Player::initialPlace() const noexcept']]],
  ['initialplacechanged_5',['initialPlaceChanged',['../d2/d1a/classQMdmmCore_1_1Player.html#a6c2b711b7f261783a93cb6f98904562c',1,'QMdmmCore::Player']]],
  ['install_20macos_6',['Install (macOS)',['../d1/dce/md_getting-started.html#autotoc_md22',1,'']]],
  ['instance_7',['Instance',['../d6/d5a/classQMdmmCore_1_1Settings.html#ac62739838e733be5d3af69cba613fc41',1,'QMdmmCore::Settings']]],
  ['intlist2variantlist_8',['intList2VariantList',['../dd/d15/namespaceQMdmmCore_1_1Utilities.html#a68d3ea0743e83dc0429d92ec57cb7b71',1,'QMdmmCore::Utilities']]],
  ['isconnected_9',['isConnected',['../d8/de3/classQMdmmNetworking_1_1Client.html#a2848e48890a697937a627b6c650df9d4',1,'QMdmmNetworking::Client']]],
  ['isgameover_10',['isGameOver',['../d8/d24/classQMdmmCore_1_1Room.html#afd0a1ad5cbf524b674183598d078f15b',1,'QMdmmCore::Room']]],
  ['isplaceadjacent_11',['isPlaceAdjacent',['../d8/da6/namespaceQMdmmCore_1_1Data.html#afa99f9142b8825c3e2b9abbe1f8e497d',1,'QMdmmCore::Data']]],
  ['isroundover_12',['isRoundOver',['../d8/d24/classQMdmmCore_1_1Room.html#a23ceac544a6d4de240a8118b63a95f95',1,'QMdmmCore::Room']]]
];
