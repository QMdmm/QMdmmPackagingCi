var searchData=
[
  ['dead_0',['dead',['../d2/d1a/classQMdmmCore_1_1Player.html#a9705455c24558d83b54853a2b47c7ff9',1,'QMdmmCore::Player']]]
];
