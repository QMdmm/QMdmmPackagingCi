var searchData=
[
  ['screenname_0',['screenname',['../d8/dec/classQMdmmNetworking_1_1Agent.html#a1dc649d7cb1b4a6adec844db4caaf3dc',1,'QMdmmNetworking::Agent::screenName'],['../dc/dcb/structQMdmmNetworking_1_1ClientConfiguration.html#a111e0542f56679ac4e25002f16d1a973',1,'QMdmmNetworking::ClientConfiguration::screenName']]],
  ['state_1',['state',['../d8/dec/classQMdmmNetworking_1_1Agent.html#ad799df33754a356795acf4f9da66ef01',1,'QMdmmNetworking::Agent']]]
];
