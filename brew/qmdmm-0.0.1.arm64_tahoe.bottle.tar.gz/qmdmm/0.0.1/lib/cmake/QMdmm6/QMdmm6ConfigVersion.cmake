# SPDX-License-Identifier: AGPL-3.0-or-later
#
# QMdmm 6 - package version file (hand-written).
#
# This is the stable shell: it publishes PACKAGE_VERSION and hands the actual
# compatibility decision to QMdmm6ConfigVersionImpl.cmake, so the policy can be
# changed without touching the shell. Qt shapes its own version files the same
# way (Qt6ConfigVersion.cmake + Qt6ConfigVersionImpl.cmake).
#
# A hand-written file is used instead of write_basic_package_version_file()
# because the generation ("6") is already carried by the package directory and
# namespace, and the version compared here is the QMdmm product version.

set(PACKAGE_VERSION "0.0.1")

# CMake input  : PACKAGE_FIND_VERSION / _MAJOR / _MINOR / _PATCH / _TWEAK
# Our input    : PACKAGE_VERSION
# Our output   : PACKAGE_VERSION_COMPATIBLE / PACKAGE_VERSION_EXACT

include("${CMAKE_CURRENT_LIST_DIR}/QMdmm6ConfigVersionImpl.cmake")
