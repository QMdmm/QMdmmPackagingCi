#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "QMdmm6::Core" for configuration "Release"
set_property(TARGET QMdmm6::Core APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(QMdmm6::Core PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libQMdmmCore6.0.0.1.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libQMdmmCore6.0.0.1.dylib"
  )

list(APPEND _cmake_import_check_targets QMdmm6::Core )
list(APPEND _cmake_import_check_files_for_QMdmm6::Core "${_IMPORT_PREFIX}/lib/libQMdmmCore6.0.0.1.dylib" )

# Import target "QMdmm6::Networking" for configuration "Release"
set_property(TARGET QMdmm6::Networking APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(QMdmm6::Networking PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libQMdmmNetworking6.0.0.1.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libQMdmmNetworking6.0.0.1.dylib"
  )

list(APPEND _cmake_import_check_targets QMdmm6::Networking )
list(APPEND _cmake_import_check_files_for_QMdmm6::Networking "${_IMPORT_PREFIX}/lib/libQMdmmNetworking6.0.0.1.dylib" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
